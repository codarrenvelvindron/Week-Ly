# Week Ly

A simple Firefox Extension, designed to show you the currrent week of the year.

Please feel free to report any bugs you may find as an issue or via Git Reports.

Official Website: http://codarren.com

## Changelog
### 1.1.2 release - Added quotes
* A random quote will show up when clicked

### 1.1.1 pre-release - Added tooltip
* Tooltip shows current week number

### 1.1.0 release - product logo - set to 09
* As a tribute to my very supportive girlfriend's Birthdate 

### 1.0.0 was born - 15/05/2017
* Just does the job, calculates week number
